<?php
global $conn;
// Hàm kết nối database
function db_connect(){
    global $conn;
    // Nếu chưa  kết nối thì kết nối
    if(!$conn){
        $conn=mysqli_connect('localhost','root','','test');
        mysqli_set_charset($conn,'utf8');
    }
}
// Hàm ngắt kết nối
function disconnect_db(){
    global $conn;
    if($conn){
        mysqli_close($conn);
    }
}
//Hàm sửa sinh viên
function edit_sv($idsv,$hoten,$gtinh,$diachi,$ngaysinh,$khoahoc,$chuyennganhid,$lopid,$email){
    global $conn;
    // Goi ham ket noi
    db_connect();
    // truy van
    $sql="UPDATE sinhvien SET 
         ID=$idsv,
         HoTen=$hoten,
         GioiTinh=$gtinh,
         DiaChi=$diachi,
         NgaySinh=$ngaysinh,
         KhoaHoc=$khoahoc,
         ChuyenNganhID=$chuyennganhid,
    --  Lop se dc load theo chuyen nganh
         LopID=$lopid,
         Email=$email";
    // Thuc thi truy van
    $query=mysqli_query($conn,$sql);
    return $query;   
}
// Hamf tim kiem thong tin sv theo id
function get_sv($idsv){
    global $conn;
    db_connect();
    // câu truy vấn
    $sql="SELECT *FROM sinhvien WHERE ID={$idsv}";
    $query=mysqli_query($conn,$sql);
    // mangr ket qua
    $result=array();
    if(mysqli_num_rows($query)>0){
        $row=mysqli_fetch_assoc($query);
        $result=$row;
    }
    return $result;
}
?>