<?php
global $conn;
// Hàm kết nối database
function db_connect(){
    global $conn;
    // Nếu chưa  kết nối thì kết nối
    if(!$conn){
        $conn=mysqli_connect('localhost','root','','test');
        mysqli_set_charset($conn,'utf8');
    }
}
// Hàm ngắt kết nối
function disconnect_db(){
    global $conn;
    if($conn){
        mysqli_close($conn);
    }
}
//Hàm sửa sinh viên
function edit_sv($idsv,$hoten,$gtinh,$diachi,$ngaysinh,$khoahoc,$chuyennganhid,$lopid,$email){
    global $conn;
    db_connect();
    $sql="UPDATE sinhvien SET 
         ID=$idsv,
         HoTen=$hoten,
         GioiTinh=$gtinh,
         DiaChi=$diachi,
         NgaySinh=$ngaysinh,
         KhoaHoc=$khoahoc,
         ChuyenNganhID=$chuyennganhid,
         LopID=$lopid,
         Email=$email WHERE ID=$idsv";

    // Thuc thi truy van
    $query=mysqli_query($conn,$sql);
    return $query;   
}



// Sửa sv
function sua_sv($idsv,$hoten,$gtinh,$diachi,$ngaysinh,$khoahoc,$tenchuyennganh,$tenlop,$email){
    global $conn;
    db_connect();
    $sql="UPDATE sinhvien SET 
         HoTen='$hoten',
         GioiTinh='$gtinh',
         DiaChi='$diachi',
         NgaySinh='$ngaysinh',
         KhoaHoc=$khoahoc,
         ChuyenNganhID=(SELECT ID FROM chuyennganh WHERE TenCN='$tenchuyennganh'),
         LopID=(SELECT ID FROM lop WHERE TenLop='$tenlop'),
         Email='$email' WHERE ID=$idsv";
    // Thuc thi truy van
    $query=mysqli_query($conn,$sql);
    $result=array();
    if(mysqli_num_rows($query)>0){
        $row=mysqli_fetch_assoc($query);
        $result=$row;
    }
    return $result;
}


// Hamf tim kiem thong tin sv theo id
function get_sv($idsv){
    global $conn;
    db_connect();
    $sql="SELECT *FROM sinhvien WHERE ID={$idsv}";
    $query=mysqli_query($conn,$sql);
    $result=array();
    if(mysqli_num_rows($query)>0){
        $row=mysqli_fetch_assoc($query);
        $result=$row;
    }
    return $result;
}
// Ham tìm kiếm tất cả thông tin của sinh viên bao gồm cả khoa và lớp
function get_ttsv($idsv){
    global $conn;
    db_connect();
    // dùng select count(* ) cũng đc
    $sql="SELECT sv.ID, LopID,HoTen, TenLop  ,TenCN ,sv.NgaySinh,gioitinh,KhoaHoc,Email,DiaChi FROM sinhvien sv,lop lp, chuyennganh cn WHERE sv.ID={$idsv} AND  sv.LopID=lp.ID AND sv.ChuyenNganhID=cn.ID" ;
    $query=mysqli_query($conn,$sql);
    $result=array();
    if(mysqli_num_rows($query)>0){
         $row=mysqli_fetch_assoc($query);
        // $result=$query->fetch_array(MYSQLI_ASSOC);
        $result=$row;
    }
   return $result;
}
// hàm trả về IDKhoa theo Tên khoa và Tenkhoa đã đặt là unique
function getTenKhoabyID($tenkhoa){ 
    global $conn;
    db_connect();
    $sql="SELECT ID FROM khoa WHERE TenKhoa={$tenkhoa}";
    $query=mysqli_query($sql);
    if(mysqli_num_rows($query)>0){
        $row=mysqli_fetch_assoc($query);
    }
    return $row;
}
?>