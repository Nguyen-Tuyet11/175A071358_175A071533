<?php
require('db_connect.php');
require('Classes/PHPExcel.php');
if(isset($_POST['btnGui'])){
    $file=$_FILES['file']['tmp_name'];// tmp_name để lấy tên tạm của file
    $objReader =PHPExcel_IOFactory::createReaderForFile($file);// tạo đối tượng reader
    $listWorkSheets=$objReader->listWorksheetNames($file);
    print_r($listWorkSheets);
    foreach($listWorkSheets as $name){
        $sql="INSERT INTO khoa( ID,TenKhoa) VALUES($khoaid,'$TenKhoa') ";
        $mysqli->query($sql);
        $lopid=$mysqli->insert_id;
        echo $lopid;
       
    }
    // $objReader->setLoadSheetsOnly('SinhVien');
    // $objExcel=$objReader ->load($file);
    // $sheetData=$objExcel->getActiveSheet()->toArray('null',true,true,true);
    // // print_r($sheetData);
    // // Lấy số dòng cao nhất trong Execl
    // $highestRow=$objExcel->setActiveSheetIndex()->getHighestRow();
    // // echo $highestRow;
    // for($row=2; $row<= $highestRow;$row++){
       
    //     $msv=$sheetData[$row]['A'];
    //     $hoten=$sheetData[$row]['B'];
    //     $gt=$sheetData[$row]['C'];
    //     $dc=$sheetData[$row]['D'];
    //     $ns=$sheetData[$row]['E'];
    //     $khoahoc=$sheetData[$row]['F'];
    //     $chuyennid=$sheetData[$row]['G'];
    //     $email=$sheetData[$row]['H'];
    //     $lopid=$sheetData[$row]['I'];
      
    //     $sql="INSERT INTO sinhvien (ID,HoTen,GioiTinh,DiaChi,NgaySinh,KhoaHoc,ChuyenNganhID,LopID,Email)
    //     VALUES($msv,'$hoten','$gt','$dc','$ns',$khoahoc,$chuyennid,$lopid,'$email')";
    //     $mysqli->query($sql);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Import data to database</title>
</head>
<body>
    <form action="" method="POST" enctype="multipart/form-data">
        <input type="file" name="file">
        <button type="submit" name="btnGui">Import</button> 
    </form>
</body>
</html>