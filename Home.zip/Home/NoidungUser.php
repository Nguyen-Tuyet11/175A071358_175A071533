
<div class="col-md-10">
        <div class="panelSV"> 
                <div class="panel-heading">
                        <h5>Thành Viên</h5>
                        <p>Tất cả người dùng đang sử dụng hệ thống.</p>
                </div>
                <div class="TongQ">
                    <b>Tất cả(36)</b> | <font style="color:blue"><a href="">Admin</a></font>(2) |
                    <font style="color:blue"><a href="">QuanLy</a></font>(3)
                    | <font style="color:blue"><a href="">GiangVien</a></font>(1)| 
                    <font style="color:blue"><a href="">Students</a></font>(30)
                </div>
                <div class="col-7 d-flex justify-content-start align-items-center" style="margin-top:12px">
                    <button class="btn btn-primary " data-toggle="modal" data-target="#myModal">
                    <i class="fa fa-plus" aria-hidden="true"></i> Edit columns
                </div>
                <table class="table table-hover" style="margin-top:20px">
                        <thead>
                        <tr>
                            <th>Tên người dùng</th>
                            <th>Họ Tên</th>
                            <th>Email</th>
                            <th>Vai trò</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td>John</td>
                            <td>Doe</td>
                            <td>john@example.com</td>
                            <td>Admin</td>
                        </tr>
                        <tr>
                            <td>Mary</td>
                            <td>Moe</td>
                            <td>mary@example.com</td>
                            <td>Students</td>
                        </tr>
                        <tr>
                            <td>July</td>
                            <td>Dooley</td>
                            <td>july@example.com</td>
                            <td>QuanLy</td>
                        </tr>
                        </tbody>
                </table>
                   
                   
                  
                </div>
</div>
                
            </div>
        </div>
    </div>
    </div>
</body>

</html>