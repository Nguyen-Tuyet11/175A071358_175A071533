
<div class="col-md-10">
        <div class="panelSV"> 
                <div class="panel-heading">
                        <h5>Thêm Người Dùng Mới</h5>
                        <p>Tạo một người sử dụng mới và thêm vào trang web.</p>
                </div>
                <form method="POST">
                      <div class="form-group row">
                            <label  class="col-sm-3 col-form-label"><b>Tên Người Dùng <em>(bắt buộc)</em></b></label>
                            <div class="col-sm-6">
                               <input type="text" class="form-control" name="ID" value="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label  class="col-sm-3 col-form-label"><b>Họ Tên</b></label>
                            <div class="col-sm-6">
                            <input type="text" class="form-control" name="" value="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label  class="col-sm-3 col-form-label"><b>Email <em>(bắt buộc)</em></b></label>
                            <div class="col-sm-6">
                            <input type="email" class="form-control" name="" value="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label  class="col-sm-3 col-form-label"><b>Password</b></label>
                            <div class="col-sm-6">
                            <input type="password" class="form-control" name="" value="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label  class="col-sm-3 col-form-label"><b>Vai trò</b></label>
                            <div class="col-sm-2">
                                <select id=""  class="form-control" name="" >
                                    <option value="">Students</option>
                                    <option value="">QuanLy</option>
                                    <option value="">GV</option>
                                    <option value="">Admin</option>
                                </select>
                            </div>
                        </div>
                        <div class="checkbox">
                           <b>Gửi thông báo đến thành viên</b>
                           <div class="col-sm-5">
                           <label><input type="checkbox">Gửi cho thành viên mới đăng kí Email</label>
                           </div>
                        </div>
                        <div class="editnut" style="display:flex; justify-content:flex-start; margin-top:20px">
                        <input type="submit" class="btn btn-primary justify-content-end " name="submit" style="margin-right:150px" value="Thêm người dùng mới">
                        </div>
    
                </form>
                   
                   
                  
                </div>
</div>
                
            </div>
        </div>
    </div>
    </div>
</body>

</html>