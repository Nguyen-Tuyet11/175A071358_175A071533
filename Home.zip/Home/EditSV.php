<?php
require('funtionSV.php');
global $id;
$id=isset($_GET['id'])?$_GET['id']:'';

if($id){
 $data=get_ttsv($id);
// echo count($data);
//  foreach($data as $data) 
 
}

// Xử lý khi submit

if(!empty($_POST['submit'])){
    $data['ID']=isset($_POST['ID'])?$_POST['ID']:'';
    $data['HoTen']=isset($_POST['HoTen'])?$_POST['HoTen']:'';
    $data['NgaySinh']=isset($_POST['NS'])?$_POST['NS']:'';
    $data['TenCN']=isset($_POST['TenCN'])?$_POST['TenCN']:'';
    $data['TenLop']=isset($_POST['NS'])?$_POST['TenLop']:'';
    $data['GioiTinh']=isset($_POST['GT'])?$_POST['GT']:'';
    $data['KhoaHoc']=isset($_POST['KhoaHoc'])?$_POST['KhoaHoc']:'';
    $data['DiaChi']=isset($_POST['DiaChi'])?$_POST['DiaChi']:'';
    $data['Email']=isset($_POST['Email'])?$_POST['Email']:'';
    $errors=array();
    if(empty($data['HoTen'])){
        $errors['HoTen']='Chưa điền tên ';
    }
    if(empty($data['NgaySinh'])){
        $errors['NgaySinh']='Chưa điền ngày sinh ';
    }
    // if(empty($data['TenCN'])){
    //     $errors['TenCN']='Chưa điền chuyên ngành ';
    // }
    // if(empty($data['TenLop'])){
    //     $errors['TenLop']='Chưa điền tên lớp ';
    // }
    // if(empty($data['GioiTinh'])){
    //     $errors['HoTen']='Chưa có giới tính ';
    // }
    if(empty($data['KhoaHoc'])){
        $errors['KhoaHoc']='Chưa điền khóa  học ';
    }
    if(empty($data['DiaChi'])){
        $errors['DiaChi']='Chưa điền địa chỉ ';
    }
    if(empty($data['Email'])){
        $errors['Email']='Chưa điền Email ';
    }
    if(!$errors ){
        sua_sv($data['ID'],$data['HoTen'],$data['GioiTinh'],$data['DiaChi'],$data['NgaySinh'],$data['KhoaHoc'],$data['TenCN'],$data['TenLop'],$data['Email']);
        header("Location:SinhVien.php");
    }
 }

?>

<?php
 include("Navbar_Admin.php");
 ?>
 <div class="main">
    <div class="row">
 <?php
 include("SlidebarAdCol2.php");
 ?>
 
 <div class="col-md-10">
                <div class="panelSV">
                   <div class="col-sm-6 container-fluid ">  
                        <div class="panel-heading justify-content-center " >
                                <h4 >Sửa Sinh Viên</h4>
                        </div>    
                   </div> 
                          
                   <form method="POST">
                       
                        <div class="editnut" style="display:flex; justify-content:flex-end;">
                        <input type="submit" class="btn btn-primary justify-content-end " onclick="confirm('Bạn chắc chắn muốn sửa chứ')"  name="submit" style="margin-right:150px" value="Cập nhật">
                        <button><a href="SinhVien.php">Quay lại</a></button>

                        </div>
                        <div class="form-group row">
                            <label  class="col-sm-2 col-form-label">Mã Sinh Viên</label>
                            <div class="col-sm-5">
                            <input type="text" class="form-control" name="ID" value="<?php echo $data['ID']; ?>">
                           
                            </div>
                        </div>
                        <div class="form-group row">
                            <label  class="col-sm-2 col-form-label">Họ Tên</label>
                            <div class="col-sm-3">
                            <input type="text" class="form-control" name="HoTen" value="<?php echo $data['HoTen']; ?>">
                            <?php if(!empty($errors['HoTen'])) echo $errors['HoTen'];?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label  class="col-sm-2 col-form-label">Chuyên Ngành</label>
                            <div class="col-sm-3">
                                <select  class="form-control" name="TenCN" >
                                    <option value="<?php echo $data['TenCN']; ?>"><?php echo $data['TenCN']; ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label  class="col-sm-2 col-form-label">Lớp</label>
                            <div class="col-sm-2">
                                <select  class="form-control" name="TenLop">
                                    <option value="<?php echo $data['TenLop'] ?>"><?php echo $data['TenLop']; ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label  class="col-sm-2 col-form-label">Ngày Sinh</label>
                            <div class="col-sm-3">
                               <input type="date" class="form-control" name="NS"  value="<?php echo $data['NgaySinh'] ;?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label  class="col-sm-2 col-form-label">Giới Tính</label>
                            <div class="col-sm-2">
                                <select id=""  class="form-control" name="GT" >
                                    <option value="Nữ">Nữ</option>
                                    <option value="Nam"<?php if($data['gioitinh']=='Nam') echo 'selected'; ?>>Nam</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label  class="col-sm-2 col-form-label">Khóa Học</label>
                            <div class="col-sm-2">
                            <input type="text" class="form-control" name="KhoaHoc" value=" <?php echo $data['KhoaHoc']; ?>">
                            <?php if(!empty($errors['KhoaHoc'])) echo $errors['KhoaHoc']; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label  class="col-sm-2 col-form-label">Địa chỉ</label>
                            <div class="col-sm-2">
                            <input type="text" class="form-control" name="DiaChi"  value="<?php echo $data['DiaChi'] ?>">
                            <?php if(!empty($errors['DiaChi'])) echo $errors['DiaChi']; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label  class="col-sm-2 col-form-label">Email</label>
                            <div class="col-sm-3">
                            <input type="email" class="form-control" name="Email"  value="<?php echo $data['Email'] ?>">
                            <?php if(!empty($errors['Email'])) echo $errors['Email']; ?>
                            </div>
                        </div>
                         
    
                    </form>
                   
                </div>
                
</div>
                
            </div>
        </div>
    </div>
    </div>
</body>

</html>