<?php
require('funtionSV.php');
$id=isset($_GET['id'])?$_GET['id']:'';

if($id){
 $data=get_sv($id);
// foreach($data as $data)
//  echo $data;

}
// TRUY VAAN MA KHONG THAY THI TUC LA K CO SV CAN SUA
?>

<?php
 include("Navbar_Admin.php");
 ?>
 <div class="main">
    <div class="row">
 <?php
 include("SlidebarAdCol2.php");
 ?>
 
 <div class="col-md-10">
                <div class="panelSV">
                   <div class="col-sm-6 ">  
                        <div class="panel-heading   " >
                                <h4 >Sửa Sinh Viên</h4>
                        </div>    
                   </div> 
                          
                   <form>
                        <div class="editnut">
                            <div class="col-7 d-flex justify-content-end align-items-center" style="margin-left:auto">
                                <button class="btn btn-primary " data-toggle="modal" data-target="#myModal">
                                 Cập nhật
                                <button class="btn btn-primary " data-toggle="modal" data-target="#myModal">
                                Quay lại
                            </div>  
                       </div>
                        <div class="form-group row">
                            <label  class="col-sm-2 col-form-label">Mã Sinh Viên</label>
                            <div class="col-sm-3">
                            <input type="text" class="form-control" id="inputPassword" value="<?php echo $data['ID']; ?>">
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label  class="col-sm-2 col-form-label">Họ Tên</label>
                            <div class="col-sm-3">
                            <input type="text" class="form-control" id="inputPassword" value="<?php echo $data['HoTen']; ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label  class="col-sm-2 col-form-label">Khoa</label>
                            <div class="col-sm-3">
                                <select name="" id="" class="form-control" id="inputPassword">
                                    <option value=""></option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label  class="col-sm-2 col-form-label">Lớp</label>
                            <div class="col-sm-2">
                                <select name="" id="" class="form-control" id="inputPassword">
                                    <option value=""></option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label  class="col-sm-2 col-form-label">Ngày Sinh</label>
                            <div class="col-sm-3">
                               <input type="date" class="form-control" id="inputPassword">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label  class="col-sm-2 col-form-label">Giới Tính</label>
                            <div class="col-sm-2">
                                <select name="" id=""  class="form-control" id="inputPassword">
                                    <option value="">Nữ</option>
                                    <option value="">Nam</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label  class="col-sm-2 col-form-label">Khóa Học</label>
                            <div class="col-sm-2">
                            <input type="text" class="form-control" id="inputPassword">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label  class="col-sm-2 col-form-label">Email</label>
                            <div class="col-sm-3">
                            <input type="email" class="form-control" id="inputPassword">
                            </div>
                        </div>
                         
    
                    </form>
                   
                </div>
                
</div>
                
            </div>
        </div>
    </div>
    </div>
</body>

</html>