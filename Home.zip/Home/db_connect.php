<?php
$mysqli=mysqli_connect('localhost','root','','test');
$mysqli->set_charset('utf8');
if(mysqli_connect_error()){
    echo'Conncet Failed: '.mysqli_connect_error();
    exit();
}
?>