<?php
 include("Navbar_Admin.php");
 ?>
 <div class="main">
    <div class="row">
 <?php
 include("SlidebarAdCol2.php");
 ?>
 
 <div class="col-md-10">
                <div class="panelSV">
                   <div class="col-md-6 container-fluid">
                       
                <div class="panel-heading   " >
                        <h4 >Thêm Sinh Viên</h4>
                </div>
                
                   <form role="form">
                   <div class="form-group">
					 
                     <label for="exampleInput">
                         Mã Sinh Viên
                     </label>
                     <input type="password" class="form-control" id="exampleInputPassword1">
                 </div>
				<div class="form-group">
					 
					<label for="exampleInput">
						Mã Lớp
					</label>
					<input type="password" class="form-control" id="exampleInputPassword1">
                </div>
                <div class="form-group">
					 
					<label for="exampleInput">
						Họ Tên
					</label>
					<input type="password" class="form-control" id="exampleInputPassword1">
                </div>
               
                <div class="form-group">
					 
					<label for="exampleInput">
						Ngày Sinh
					</label>
					<input type="password" class="form-control" id="exampleInputPassword1">
                </div>
                <div class="form-group">
					 
					<label for="exampleInput">
						Giới Tính
					</label>
					<input type="password" class="form-control" id="exampleInputPassword1">
                </div>
                <div class="form-group">
					 
					<label for="exampleInput">
						Khóa Học
					</label>
					<input type="password" class="form-control" id="exampleInputPassword1">
                </div>
                <div class="form-group">
					 
					<label for="exampleInput">
						Email
					</label>
					<input type="password" class="form-control" id="exampleInputPassword1">
				</div>
				<button type="submit" class="btn btn-primary col-md-4" >
					Add
				</button>
			</form>
                  
                   </div>
                   
                </div>
</div>
                
            </div>
        </div>
    </div>
    </div>
</body>

</html>