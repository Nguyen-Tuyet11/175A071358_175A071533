
            <div class="col-md-2">
                <div class="slidebar">
                    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                        <a  href="Home.php" ><i class="fa fa-tachometer"  aria-hidden="true"></i>  Dashboard</a>
                        <a href="SinhVien.php"><i class="fa fa-users" aria-hidden="true"></i><span>Sinh Viên</span></a>
                        <a >Danh Sách Sinh Viên</a>
                        <a href="Diem.php" >Điểm</a>
                        <a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#" role="tab" aria-controls="v-pills-profile" aria-selected="false">Học Bổng</a>
                        <a href="GiangVien.php"><i class="fa fa-user" aria-hidden="true"></i><span>Giảng Viên</span></a>
                        <a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#" role="tab" aria-controls="v-pills-profile" aria-selected="false">Danh sách Giảng Viên</a>
                        <a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#" role="tab" aria-controls="v-pills-profile" aria-selected="false"><i class="fa fa-calendar" aria-hidden="true"></i><span>Lịch Dạy</span></a>
                        <a href="MH.php"><i class="fa fa-book" aria-hidden="true"></i><span>Môn Học</span></a>
                        <a class="nav-link" id="v-pills-messages-tab" data-toggle="pill" href="#" role="tab" aria-controls="v-pills-messages" aria-selected="false">Lớp học phần</a>
                        <a class="nav-link" id="v-pills-settings-tab" data-toggle="pill" href="#" role="tab" aria-controls="v-pills-settings" aria-selected="false">Lớp Chuyên Ngành</a>
                        <a class="nav-link" id="v-pills-settings-tab" data-toggle="pill" href="#" role="tab" aria-controls="v-pills-settings" aria-selected="false">Chuyên Ngành</a>
                        <a class="nav-link" id="v-pills-settings-tab" data-toggle="pill" href="#" role="tab" aria-controls="v-pills-settings" aria-selected="false"><i class="fa fa-address-card" aria-hidden="true"></i><span>Khoa</span></a>
                        <a class="nav-link" id="v-pills-settings-tab" data-toggle="pill" href="#" role="tab" aria-controls="v-pills-settings" aria-selected="false">Ngành Học</a>
                         Thành Viên
                        <a href="User.php">Tất cả người dùng</a>
                        <a href="UserNew.php">Thêm Người Dùng</a>
                        <a class="nav-link" id="v-pills-settings-tab" data-toggle="pill" href="#" role="tab" aria-controls="v-pills-settings" aria-selected="false">Liên Hệ</a>
                        <a class="nav-link" id="v-pills-settings-tab" data-toggle="pill" href="#" role="tab" aria-controls="v-pills-settings" aria-selected="false"></a>
                        <a href=""></a>
                        <a href=""></a>

                    </div>
                </div>

</div>
